// script.js
// ----------------------------------------------------
// Tic‑Tac‑Toe – full game with Two‑Player and Single‑Player modes
// ----------------------------------------------------

// ------- Game state -------
let board = Array(9).fill('');               // '' | 'X' | 'O'
let currentPlayer = 'X';                     // X always starts
let gameActive = true;
let scores = { X: 0, O: 0 };
let mode = 'two';                             // 'two' or 'single'
let difficulty = 'easy';                     // easy, medium, hard
let thinking = false;                        // true while AI is computing

// Winning combinations (indices of board array)
const winCombos = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // cols
  [0, 4, 8], [2, 4, 6]              // diagonals
];

// ------- Cached DOM elements -------
let statusEl, scoreXEl, scoreOEl, boardEl, restartBtn, resetBtn;
let modeSelectEl, difficultySelectEl, difficultyLabelEl;

// ----------------------------------------------------
// Initialisation
// ----------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
  // Grab static elements
  statusEl = document.getElementById('status');
  scoreXEl = document.getElementById('score-x');
  scoreOEl = document.getElementById('score-o');
  boardEl = document.getElementById('game-board');
  restartBtn = document.getElementById('restart');
  resetBtn = document.getElementById('reset');
  modeSelectEl = document.getElementById('mode-select');
  difficultySelectEl = document.getElementById('difficulty-select');
  difficultyLabelEl = document.querySelector('.difficulty-label');

  // Build board cells if not already present (first load)
  if (boardEl.children.length === 0) {
    for (let i = 0; i < 9; i++) {
      const cell = document.createElement('div');
      cell.className = 'cell';
      cell.dataset.index = i;
      boardEl.appendChild(cell);
    }
  }

  // Attach listeners to cells
  boardEl.querySelectorAll('.cell').forEach(cell => {
    cell.addEventListener('click', onCellClick);
  });

  // Control buttons
  restartBtn.addEventListener('click', restartGame);
  resetBtn.addEventListener('click', resetScore);

  // Mode selector handling
  modeSelectEl.addEventListener('change', onModeChange);
  difficultySelectEl.addEventListener('change', e => {
    difficulty = e.target.value;
  });

  // Initialise UI
  updateStatus();
  updateScoreboard();
  onModeChange(); // set initial visibility of difficulty selector
});

// ----------------------------------------------------
// UI Handlers
// ----------------------------------------------------
function onModeChange() {
  mode = modeSelectEl.value; // 'two' or 'single'
  if (mode === 'single') {
    difficultySelectEl.style.display = 'inline-block';
    difficultyLabelEl.style.display = 'inline-block';
  } else {
    difficultySelectEl.style.display = 'none';
    difficultyLabelEl.style.display = 'none';
  }
  // When switching modes, we simply restart the game to avoid illegal state.
  restartGame();
}

function onCellClick(e) {
  if (!gameActive || thinking) return; // ignore during AI turn or after game over

  const cell = e.target;
  const index = parseInt(cell.dataset.index, 10);

  // In single‑player mode only allow human to click when it's X's turn
  if (mode === 'single' && currentPlayer !== 'X') return;

  if (board[index] !== '') return; // occupied cell

  makeMove(index, currentPlayer);

  if (checkWin()) {
    handleWin();
  } else if (checkDraw()) {
    handleDraw();
  } else {
    // Switch player
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    updateStatus();
    // If we just switched to computer, trigger its move
    if (mode === 'single' && currentPlayer === 'O') {
      computerMove();
    }
  }
}

function makeMove(idx, player) {
  board[idx] = player;
  const cell = boardEl.querySelector(`.cell[data-index='${idx}']`);
  cell.textContent = player;
  cell.classList.add(player.toLowerCase()); // adds .x or .o for styling
}

function restartGame() {
  // Fade out board for smooth transition
  boardEl.classList.add('resetting');
  setTimeout(() => {
    board = Array(9).fill('');
    gameActive = true;
    currentPlayer = 'X';
    thinking = false;
    boardEl.querySelectorAll('.cell').forEach(cell => {
      cell.textContent = '';
      cell.classList.remove('x', 'o', 'win');
      cell.style.boxShadow = '';
    });
    boardEl.classList.remove('resetting');
    updateStatus();
    // If playing single player and computer starts (not the case here – X always human),
    // we could invoke computerMove() here.
  }, 300); // match CSS transition duration
}

function resetScore() {
  scores = { X: 0, O: 0 };
  updateScoreboard();
  restartGame();
}

// ----------------------------------------------------
// Game Logic Helpers
// ----------------------------------------------------
function checkWin() {
  return winCombos.some(combo => {
    const [a, b, c] = combo;
    return board[a] && board[a] === board[b] && board[a] === board[c];
  });
}

function handleWin() {
  gameActive = false;
  // Highlight winning combo
  const winCombo = winCombos.find(combo => {
    const [a, b, c] = combo;
    return board[a] && board[a] === board[b] && board[a] === board[c];
  });
  if (winCombo) {
    winCombo.forEach(idx => {
      const cell = boardEl.querySelector(`.cell[data-index='${idx}']`);
      cell.classList.add('win');
      cell.style.boxShadow = currentPlayer === 'X' ? '0 0 12px #00e0ff' : '0 0 12px #ff00aa';
    });
  }
  // Update scoreboard
  scores[currentPlayer]++;
  updateScoreboard();
  statusEl.textContent = `Player ${currentPlayer} wins!`;
}

function checkDraw() {
  return board.every(cell => cell !== '');
}

function handleDraw() {
  gameActive = false;
  statusEl.textContent = "It's a draw!";
}

function updateStatus() {
  if (thinking) {
    statusEl.textContent = 'Computer Thinking...';
  } else if (mode === 'single') {
    statusEl.textContent = currentPlayer === 'X' ? "Your turn (X)" : "Computer's turn (O)";
  } else {
    statusEl.textContent = `Player ${currentPlayer}'s turn`;
  }
}

function updateScoreboard() {
  scoreXEl.textContent = scores.X;
  scoreOEl.textContent = scores.O;
}

// ----------------------------------------------------
// AI Helpers (single‑player mode)
// ----------------------------------------------------
function computerMove() {
  thinking = true;
  updateStatus();
  // Simulate a short think time for UX
  setTimeout(() => {
    const moveIdx = chooseAIMove();
    makeMove(moveIdx, 'O');
    thinking = false;

    if (checkWin()) {
      handleWin();
    } else if (checkDraw()) {
      handleDraw();
    } else {
      currentPlayer = 'X';
      updateStatus();
    }
  }, 300); // 300 ms delay matches board transition
}

function chooseAIMove() {
  const empty = board.map((v, i) => v === '' ? i : null).filter(v => v !== null);
  if (difficulty === 'easy') {
    return randomChoice(empty);
  }
  if (difficulty === 'medium') {
    // 1) win if possible
    for (const i of empty) {
      board[i] = 'O';
      if (isWinning('O')) { board[i] = ''; return i; }
      board[i] = '';
    }
    // 2) block opponent win
    for (const i of empty) {
      board[i] = 'X';
      if (isWinning('X')) { board[i] = ''; return i; }
      board[i] = '';
    }
    // 3) otherwise random
    return randomChoice(empty);
  }
  // difficulty === 'hard' – Minimax
  const best = minimax(board, 'O');
  return best.index;
}

function randomChoice(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function isWinning(player) {
  return winCombos.some(combo => {
    const [a, b, c] = combo;
    return board[a] === player && board[b] === player && board[c] === player;
  });
}

// Minimax returns {score, index}
function minimax(newBoard, player) {
  const availSpots = newBoard.map((v, i) => v === '' ? i : null).filter(v => v !== null);

  // Terminal states
  if (isBoardWin(newBoard, 'X')) {
    return { score: -10 };
  } else if (isBoardWin(newBoard, 'O')) {
    return { score: 10 };
  } else if (availSpots.length === 0) {
    return { score: 0 };
  }

  const moves = [];

  for (const i of availSpots) {
    const move = {};
    move.index = i;
    newBoard[i] = player;

    if (player === 'O') {
      const result = minimax(newBoard, 'X');
      move.score = result.score;
    } else {
      const result = minimax(newBoard, 'O');
      move.score = result.score;
    }

    newBoard[i] = '';
    moves.push(move);
  }

  // Choose best move
  let bestMove;
  if (player === 'O') {
    let bestScore = -Infinity;
    for (const m of moves) {
      if (m.score > bestScore) {
        bestScore = m.score;
        bestMove = m;
      }
    }
  } else {
    let bestScore = Infinity;
    for (const m of moves) {
      if (m.score < bestScore) {
        bestScore = m.score;
        bestMove = m;
      }
    }
  }
  return bestMove;
}

function isBoardWin(b, player) {
  return winCombos.some(combo => {
    const [a, bIdx, c] = combo;
    return b[a] === player && b[bIdx] === player && b[c] === player;
  });
}
